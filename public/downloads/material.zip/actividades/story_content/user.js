function ExecuteScript(strId)
{
  switch (strId)
  {
      case "64oSkxk92jj":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

